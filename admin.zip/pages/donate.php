<?php

require_once __DIR__ . '/../includes/static-pages.php';
$staticPages = bethammi_static_pages();
$staticPageSlug = 'donate';
if (!isset($staticPages[$staticPageSlug])) {
    http_response_code(404);
    exit('Page not found.');
}
$isStaticPage = true;
$contentKind = 'page';
$contentSlug = $staticPageSlug;
$staticPageTitle = $staticPages[$staticPageSlug];
$pageTitle = $staticPageTitle . ' | Beth Ammi Christian Fellowship Church';
$pageDescription = 'Learn about ' . $staticPageTitle . ' at Beth Ammi Christian Fellowship Church.';
$pageScripts = ['page.js'];
require __DIR__ . '/../includes/site-head.php';
require __DIR__ . '/../includes/site-header.php';
?>
<main id="main">
  <section class="page-banner" aria-labelledby="page-title">
    <div class="container">
      <nav class="breadcrumbs" aria-label="Breadcrumb"><a href="../index">Home</a><span aria-hidden="true">/</span><span id="breadcrumb-label"><?= bethammi_escape($staticPageTitle) ?></span></nav>
      <p class="eyebrow eyebrow--light"><span></span><span id="page-kicker">Beth Ammi Christian Fellowship Church</span></p>
      <h1 id="page-title"><?= bethammi_escape($staticPageTitle) ?></h1>
      <p class="page-banner__summary" id="page-summary" hidden></p>
    </div>
  </section>
  <section class="container page-layout" id="page-layout">
    <article class="page-article">
      <div class="remote-content" id="page-content">
        <template id="static-page-content">
              <div data-elementor-type="wp-page" data-elementor-id="1736" class="elementor elementor-1736">
                      <section class="elementor-section elementor-top-section elementor-element elementor-element-ombmal8 elementor-section-boxed elementor-section-height-default elementor-section-height-default wpr-particle-no wpr-jarallax-no wpr-parallax-no wpr-sticky-section-no wpr-column-slider-no wpr-equal-height-no" data-id="ombmal8" data-element_type="section" data-e-type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                        <div class="elementor-background-overlay"></div>
                        <div class="elementor-container elementor-column-gap-no">
                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-777ee66" data-id="777ee66" data-element_type="column" data-e-type="column">
                <div class="elementor-widget-wrap elementor-element-populated">
                      <div class="elementor-element elementor-element-626b6b8 elementor-widget elementor-widget-heading" data-id="626b6b8" data-element_type="widget" data-e-type="widget" data-widget_type="heading.default">
                  <div class="elementor-widget-container">
                    <h1 class="elementor-heading-title elementor-size-default">DONATE TO US</h1>        </div>
                  </div>
                    </div>
              </div>
                    </div>
              </section>
                  <section class="elementor-section elementor-top-section elementor-element elementor-element-rke79ok elementor-section-boxed elementor-section-height-default elementor-section-height-default wpr-particle-no wpr-jarallax-no wpr-parallax-no wpr-sticky-section-no wpr-column-slider-no wpr-equal-height-no" data-id="rke79ok" data-element_type="section" data-e-type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                      <div class="elementor-container elementor-column-gap-no">
                    <div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-9a83b73" data-id="9a83b73" data-element_type="column" data-e-type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                <div class="elementor-widget-wrap elementor-element-populated">
                      <div class="elementor-element elementor-element-73c5b0b elementor-widget elementor-widget-toggle" data-id="73c5b0b" data-element_type="widget" data-e-type="widget" data-widget_type="toggle.default">
                  <div class="elementor-widget-container">
                        <div class="elementor-toggle">
                        <div class="elementor-toggle-item">
                    <div id="elementor-tab-title-1211" class="elementor-tab-title" data-tab="1" role="button" aria-controls="elementor-tab-content-1211" aria-expanded="false">
                                  <span class="elementor-toggle-icon elementor-toggle-icon-left" aria-hidden="true">
                                        <span class="elementor-toggle-icon-closed"><i class="fas fa-caret-right"></i></span>
                          <span class="elementor-toggle-icon-opened"><i class="elementor-toggle-icon-opened fas fa-caret-up"></i></span>
                                    </span>
                                  <a class="elementor-toggle-title" tabindex="0">DONATE BY CHECK</a>
                    </div>

                    <div id="elementor-tab-content-1211" class="elementor-tab-content elementor-clearfix" data-tab="1" role="region" aria-labelledby="elementor-tab-title-1211"><p>Please make checks payable to Bethammi Christian Fellowship Church and mail to Bethammi Christian Fellowship Church, Rusororo Sector New KBS garage.</p></div>
                  </div>
                          </div>
                      </div>
                  </div>
                    </div>
              </div>
                  <div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-d770cb6" data-id="d770cb6" data-element_type="column" data-e-type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                <div class="elementor-widget-wrap elementor-element-populated">
                      <div class="elementor-element elementor-element-35069b4 elementor-widget elementor-widget-toggle" data-id="35069b4" data-element_type="widget" data-e-type="widget" data-widget_type="toggle.default">
                  <div class="elementor-widget-container">
                        <div class="elementor-toggle">
                        <div class="elementor-toggle-item">
                    <div id="elementor-tab-title-5561" class="elementor-tab-title" data-tab="1" role="button" aria-controls="elementor-tab-content-5561" aria-expanded="false">
                                  <span class="elementor-toggle-icon elementor-toggle-icon-left" aria-hidden="true">
                                        <span class="elementor-toggle-icon-closed"><i class="fas fa-caret-right"></i></span>
                          <span class="elementor-toggle-icon-opened"><i class="elementor-toggle-icon-opened fas fa-caret-up"></i></span>
                                    </span>
                                  <a class="elementor-toggle-title" tabindex="0">Danate Through Wire Transfer</a>
                    </div>

                    <div id="elementor-tab-content-5561" class="elementor-tab-content elementor-clearfix" data-tab="1" role="region" aria-labelledby="elementor-tab-title-5561"><p>Please Contact Alfred Gatabazi at +250788451308 for wire transfer information</p></div>
                  </div>
                          </div>
                      </div>
                  </div>
                    </div>
              </div>
                  <div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-d4793d3" data-id="d4793d3" data-element_type="column" data-e-type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                <div class="elementor-widget-wrap elementor-element-populated">
                      <div class="elementor-element elementor-element-8b70051 elementor-widget elementor-widget-toggle" data-id="8b70051" data-element_type="widget" data-e-type="widget" data-widget_type="toggle.default">
                  <div class="elementor-widget-container">
                        <div class="elementor-toggle">
                        <div class="elementor-toggle-item">
                    <div id="elementor-tab-title-1461" class="elementor-tab-title" data-tab="1" role="button" aria-controls="elementor-tab-content-1461" aria-expanded="false">
                                  <span class="elementor-toggle-icon elementor-toggle-icon-left" aria-hidden="true">
                                        <span class="elementor-toggle-icon-closed"><i class="fas fa-caret-right"></i></span>
                          <span class="elementor-toggle-icon-opened"><i class="elementor-toggle-icon-opened fas fa-caret-up"></i></span>
                                    </span>
                                  <a class="elementor-toggle-title" tabindex="0">Donate Through Mobile Money</a>
                    </div>

                    <div id="elementor-tab-content-1461" class="elementor-tab-content elementor-clearfix" data-tab="1" role="region" aria-labelledby="elementor-tab-title-1461"><p>Using MTN Mobile Money, press <span style="font-weight: bold;">*182*8*1*007002#</span> and Follow the instruction. if you are outside of Rwanda you can donate through <a style="background-color: #ffffff;" href="https://www.worldremit.com/" target="_blank" rel="noopener">World Remit</a> and use this number of Recipient <span style="font-weight: bold;">0788482324 Alfred Gatabazi</span></p></div>
                  </div>
                          </div>
                      </div>
                  </div>
                    </div>
              </div>
                    </div>
              </section>
                  <section class="elementor-section elementor-top-section elementor-element elementor-element-07553c7 elementor-section-boxed elementor-section-height-default elementor-section-height-default wpr-particle-no wpr-jarallax-no wpr-parallax-no wpr-sticky-section-no wpr-column-slider-no wpr-equal-height-no" data-id="07553c7" data-element_type="section" data-e-type="section">
                      <div class="elementor-container elementor-column-gap-default">
                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-626aa65" data-id="626aa65" data-element_type="column" data-e-type="column">
                <div class="elementor-widget-wrap elementor-element-populated">
                      <div class="elementor-element elementor-element-68cd1cc elementor-widget elementor-widget-wpforms" data-id="68cd1cc" data-element_type="widget" data-e-type="widget" data-widget_type="wpforms.default">
                  <div class="elementor-widget-container">
                    <div class="wpforms-container " id="wpforms-2075"><form id="wpforms-form-2075" class="wpforms-validate wpforms-form wpforms-ajax-form" data-formid="2075" method="post" enctype="multipart/form-data" action="/wp-json/wp/v2/pages?per_page=100&#038;_fields=slug%2Cdate%2Ctitle%2Clink%2Ccontent%2Cexcerpt%2Cfeatured_media" data-token="3f98deec9cdcf943cf7941709f911492" data-token-time="1791726723"><noscript class="wpforms-error-noscript">Please enable JavaScript in your browser to complete this form.</noscript><div class="wpforms-field-container"><div id="wpforms-2075-field_6-container" class="wpforms-field wpforms-field-radio wpforms-list-3-columns" data-field-id="6"><label class="wpforms-field-label">Donate to a specific Ministry <span class="wpforms-required-label">*</span></label><ul id="wpforms-2075-field_6" class="wpforms-randomize wpforms-field-required"><li class="choice-1 depth-1"><input type="radio" id="wpforms-2075-field_6_1" name="wpforms[fields][6]" value="Children Ministries" required ><label class="wpforms-field-label-inline" for="wpforms-2075-field_6_1">Children Ministries</label></li><li class="choice-2 depth-1"><input type="radio" id="wpforms-2075-field_6_2" name="wpforms[fields][6]" value="Women Ministries" required ><label class="wpforms-field-label-inline" for="wpforms-2075-field_6_2">Women Ministries</label></li><li class="choice-3 depth-1"><input type="radio" id="wpforms-2075-field_6_3" name="wpforms[fields][6]" value="Evangelism Ministries" required ><label class="wpforms-field-label-inline" for="wpforms-2075-field_6_3">Evangelism Ministries</label></li><li class="choice-4 depth-1"><input type="radio" id="wpforms-2075-field_6_4" name="wpforms[fields][6]" value="Support our Team" required ><label class="wpforms-field-label-inline" for="wpforms-2075-field_6_4">Support our Team</label></li><li class="choice-5 depth-1"><input type="radio" id="wpforms-2075-field_6_5" name="wpforms[fields][6]" value="Work on Priority" required ><label class="wpforms-field-label-inline" for="wpforms-2075-field_6_5">Work on Priority</label></li></ul><div class="wpforms-field-description">we ensure you that we will use your donation Wisely, and your contribution will help this ministry reach its goal.</div></div><div id="wpforms-2075-field_3-container" class="wpforms-field wpforms-field-name" data-field-id="3"><label class="wpforms-field-label">Name <span class="wpforms-required-label">*</span></label><div class="wpforms-field-row wpforms-field-medium"><div class="wpforms-field-row-block wpforms-first wpforms-one-half"><input type="text" id="wpforms-2075-field_3" class="wpforms-field-name-first wpforms-field-required" name="wpforms[fields][3][first]" required><label for="wpforms-2075-field_3" class="wpforms-field-sublabel after">First</label></div><div class="wpforms-field-row-block wpforms-one-half"><input type="text" id="wpforms-2075-field_3-last" class="wpforms-field-name-last wpforms-field-required" name="wpforms[fields][3][last]" required><label for="wpforms-2075-field_3-last" class="wpforms-field-sublabel after">Last</label></div></div></div><div id="wpforms-2075-field_4-container" class="wpforms-field wpforms-field-email" data-field-id="4"><label class="wpforms-field-label" for="wpforms-2075-field_4">Email <span class="wpforms-required-label">*</span></label><input type="email" id="wpforms-2075-field_4" class="wpforms-field-medium wpforms-field-required" name="wpforms[fields][4]" spellcheck="false" required></div><div id="wpforms-2075-field_9-container" class="wpforms-field wpforms-field-radio wpforms-list-3-columns" data-field-id="9"><label class="wpforms-field-label">Donate</label><ul id="wpforms-2075-field_9"><li class="choice-1 depth-1"><input type="radio" id="wpforms-2075-field_9_1" name="wpforms[fields][9]" value="$5"  ><label class="wpforms-field-label-inline" for="wpforms-2075-field_9_1">$5</label></li><li class="choice-2 depth-1"><input type="radio" id="wpforms-2075-field_9_2" name="wpforms[fields][9]" value="$10"  ><label class="wpforms-field-label-inline" for="wpforms-2075-field_9_2">$10</label></li><li class="choice-3 depth-1"><input type="radio" id="wpforms-2075-field_9_3" name="wpforms[fields][9]" value="$15"  ><label class="wpforms-field-label-inline" for="wpforms-2075-field_9_3">$15</label></li><li class="choice-4 depth-1"><input type="radio" id="wpforms-2075-field_9_4" name="wpforms[fields][9]" value="$20"  ><label class="wpforms-field-label-inline" for="wpforms-2075-field_9_4">$20</label></li><li class="choice-5 depth-1"><input type="radio" id="wpforms-2075-field_9_5" name="wpforms[fields][9]" value="$30"  ><label class="wpforms-field-label-inline" for="wpforms-2075-field_9_5">$30</label></li><li class="choice-6 depth-1"><input type="radio" id="wpforms-2075-field_9_6" name="wpforms[fields][9]" value="$50"  ><label class="wpforms-field-label-inline" for="wpforms-2075-field_9_6">$50</label></li><li class="choice-7 depth-1"><input type="radio" id="wpforms-2075-field_9_7" name="wpforms[fields][9]" value="$100"  ><label class="wpforms-field-label-inline" for="wpforms-2075-field_9_7">$100</label></li><li class="choice-8 depth-1"><input type="radio" id="wpforms-2075-field_9_8" name="wpforms[fields][9]" value="$200"  ><label class="wpforms-field-label-inline" for="wpforms-2075-field_9_8">$200</label></li><li class="choice-9 depth-1"><input type="radio" id="wpforms-2075-field_9_9" name="wpforms[fields][9]" value="$500"  ><label class="wpforms-field-label-inline" for="wpforms-2075-field_9_9">$500</label></li></ul></div><div id="wpforms-2075-field_10-container" class="wpforms-field wpforms-field-text" data-field-id="10"><label class="wpforms-field-label" for="wpforms-2075-field_10">Or Enter Amount</label><input type="text" id="wpforms-2075-field_10" class="wpforms-field-medium" name="wpforms[fields][10]" ><div class="wpforms-field-description">We thank you for your Golden heart and We will contact you Shortly for Further Information on how to make a donation!

          Thank you so Much!</div></div></div><!-- .wpforms-field-container --><div class="wpforms-submit-container" ><input type="hidden" name="wpforms[id]" value="2075"><input type="hidden" name="wpforms[time_token]" value="1791726723.0b0dcb357f18bf645de4d4c89930e16f2d882abfe206a6654d1e42a5ea03e4ae"><input type="hidden" name="page_title" value=""><input type="hidden" name="page_url" value="https://www.bethammicfc.org/wp-json/wp/v2/pages?per_page=100&#038;_fields=slug,date,title,link,content,excerpt,featured_media"><input type="hidden" name="url_referer" value=""><button type="submit" name="wpforms[submit]" id="wpforms-submit-2075" class="wpforms-submit" data-alt-text="Sending..." data-submit-text="Contact us" aria-live="assertive" value="wpforms-submit">Contact us</button><img loading="lazy" decoding="async" src="https://www.bethammicfc.org/wp-content/plugins/wpforms-lite/assets/images/submit-spin.svg" class="wpforms-submit-spinner" style="display: none;" width="26" height="26" alt="Loading"></div></form></div>  <!-- .wpforms-container -->        </div>
                  </div>
                    </div>
              </div>
                    </div>
              </section>
                  </div>

        </template>
      </div>
    </article>
    <aside class="page-sidebar" id="page-sidebar">
            <div class="sidebar-card sidebar-card--visit">
              <p class="eyebrow"><span></span> You are welcome</p>
              <h2>Come worship<br>with us.</h2>
              <p>Join the Beth Ammi community for worship, prayer, fellowship, and the Word of God.</p>
              <a class="btn button button--navy" href="<?= bethammi_escape($siteRoot ?? '') ?>index#gather">Service times <span aria-hidden="true">↗</span></a>
            </div>
            <div class="sidebar-card sidebar-card--contact">
              <span class="sidebar-card__label">NEED TO GET IN TOUCH?</span>
              <a href="tel:+250788482324">+250 788 482 324</a>
              <a href="https://wa.me/250788482324">WhatsApp us ↗</a>
            </div>
          </aside>
  </section>
</main>
<?php require __DIR__ . '/../includes/site-footer.php'; ?>
